pte_t* walkpgdir(pde_t* pgdir, const void* va, int alloc);

